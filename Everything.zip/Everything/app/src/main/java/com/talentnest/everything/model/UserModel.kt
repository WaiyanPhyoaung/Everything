package com.talentnest.everything.model

class UserModel(
    val password: String? = null,
    val phoneNumber: String? = null ,
    val userName: String? = null
    )