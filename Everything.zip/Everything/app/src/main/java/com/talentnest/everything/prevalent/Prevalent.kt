package com.talentnest.everything.prevalent

import com.talentnest.everything.model.UserModel

class Prevalent {
    companion object{
        private lateinit var currentOnlineUser : UserModel
    }
}